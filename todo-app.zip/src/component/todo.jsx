import React, { useState } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Box } from '@mui/system';
import { postTodo } from '../redux/Action/index';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Typography } from '@mui/material';
import TodoList from './todoList';

const Todo = () => {
    const [textField, setTextField] = useState();
    const dataList = useSelector((state) => state.todoReducer.todoList)
    const dispatch = useDispatch();
    console.log(dataList);

    const addtodoFun = () => {
        dispatch(postTodo(textField),
            setTextField(''))
    }

    return (
        <>
            <Box sx={{ m: 5 }} textAlign='center'>
                <Paper elevation={5} sx={{ width: "30%", height: '60vh' }}>
                    <Typography variant='h5' >Todo App</Typography>
                    <TextField sx={{ mt: 2 }} size="small" value={textField}
                        onChange={(event) => setTextField(event.target.value)} />
                    <Button variant="contained" sx={{ ml: 0.5, mt: 2.2 }} onClick={addtodoFun}>
                        Add Todo
                    </Button>
                    {
                        dataList.map((a) => {
                            return (<>
                                <TodoList a={a} />
                            </>)
                        })
                    }
                </Paper>
            </Box>
        </>
    )
}

export default Todo;
